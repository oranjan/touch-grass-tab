function a(r){let e=r.toLowerCase().trim();return e=e.replace(/^(https?:\/\/)?(www\.)?/,""),e=e.replace(/\/.*$/,""),e=e.replace(/^\.+|\.+$/g,""),e}export{a as n};
